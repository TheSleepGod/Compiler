//
// Created by hhw on 2022/9/15.
//
#include<cstdio>
#include <map>

using namespace std;
map<string,string> reservedWord;
string Int = "int";
string Const = "const";
string While = "while";
string Main = "main";
string Break = "break";
string Continue = "continue";
string If = "if";
string Else = "else";
string Getint = "getint";
string Printf = "printf";
string Return = "return";
string Void = "void";
void ReservedInit() {
    reservedWord.insert(pair<string,string>(Int,"INTTK"));
    reservedWord.insert(pair<string,string>(Const,"CONSTTK"));
    reservedWord.insert(pair<string,string>(Main,"MAINTK"));
    reservedWord.insert(pair<string,string>(Break,"BREAKTK"));
    reservedWord.insert(pair<string,string>(Continue,"CONTINUETK"));
    reservedWord.insert(pair<string,string>(If,"IFTK"));
    reservedWord.insert(pair<string,string>(Else,"ELSETK"));
    reservedWord.insert(pair<string,string>(While,"WHILETK"));
    reservedWord.insert(pair<string,string>(Getint,"GETINTTK"));
    reservedWord.insert(pair<string,string>(Printf,"PRINTFTK"));
    reservedWord.insert(pair<string,string>(Return,"RETURNTK"));
    reservedWord.insert(pair<string,string>(Void,"VOIDTK"));

    reservedWord.insert(pair<string,string>("!","NOT"));
    reservedWord.insert(pair<string,string>("&&","AND"));
    reservedWord.insert(pair<string,string>("||","OR"));
    reservedWord.insert(pair<string,string>("+","PLUS"));
    reservedWord.insert(pair<string,string>("-","MINU"));
    reservedWord.insert(pair<string,string>("*","MULT"));
    reservedWord.insert(pair<string,string>("/","DIV"));
    reservedWord.insert(pair<string,string>("%","MOD"));
    reservedWord.insert(pair<string,string>("<","LSS"));
    reservedWord.insert(pair<string,string>("<=","LEQ"));
    reservedWord.insert(pair<string,string>(">","GRE"));
    reservedWord.insert(pair<string,string>(">=","GEQ"));
    reservedWord.insert(pair<string,string>("==","EQL"));
    reservedWord.insert(pair<string,string>("!=","NEQ"));
    reservedWord.insert(pair<string,string>("=","ASSIGN"));
    reservedWord.insert(pair<string,string>(";","SEMICN"));
    reservedWord.insert(pair<string,string>(",","COMMA"));
    reservedWord.insert(pair<string,string>("(","LPARENT"));
    reservedWord.insert(pair<string,string>(")","RPARENT"));
    reservedWord.insert(pair<string,string>("[","LBRACK"));
    reservedWord.insert(pair<string,string>("]","RBRACK"));
    reservedWord.insert(pair<string,string>("{","LBRACE"));
    reservedWord.insert(pair<string,string>("}","RBRACE"));
}
bool isOneChar(char a) {
    if(a == '(' || a == ')'|| a == '{' || a == '}'
       || a == ';'|| a == '[' || a == ']' || a == ','
       || a == '+' || a == '-' || a == '*'|| a == '%')
        return true;
    else
        return false;
}

bool isIndent(char a) {
    return isalpha(a) || isdigit(a) || a == '_';
}

#ifndef COMPILER_DEPENDENCIES_H
#define COMPILER_DEPENDENCIES_H

#endif //COMPILER_DEPENDENCIES_H
