#include <iostream>
#include "Lexical.h"

using namespace std;
int main() {
    freopen("testfile.txt","r",stdin);
    freopen("output.txt","w",stdout);
    Lexical();
    return 0;
}
