#pragma clang diagnostic push
#pragma ide diagnostic ignored "misc-no-recursion"
//
// Created by hhw on 2022/9/20.
//
// we must keep at the beginning of Syntactic
// the word was the first of Syntactic
// we need move now_token to next at the end of Syntactic

// there has loop chain, the beginning of loop chain were defined in Dependencies

#ifndef COMPILER_SYNTACTIC_H
#define COMPILER_SYNTACTIC_H
#include "Dependencies.h"
#include "Quaternion.h"
#include "Mips.h"
using namespace std;
int now_token = 0;
int cycleDepth = 0;
bool Global = true;
int near_return_final = 0;
int Exp() {
    int return_value;
    return_value = AddExp();
    printLexicalExtra("<Exp>\n");
    return return_value;
}
int LVal() {
    st tmp[3];
    int return_value;
    tmp[1] = ErrorSt;
    tmp[2] = ErrorSt;
    identTable TestTmp = CheckDefineInIdent(now_token);
    if(TestTmp.name == "error!")
        ErrorHanding_c(outLexicalLine[now_token]);
    return_value = TestTmp.ident_kind;
    printLexicalOutput(now_token++); //Ident
    while(outLexicalToken[now_token] == "LBRACK") {
        printLexicalOutput(now_token++);    //  [
        return_value--;
        Exp();
        tmp[2-return_value] = allStack.top();
        allStack.pop();
        if(outLexicalToken[now_token] != "RBRACK")
            ErrorHanding_k(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++); //]
    }
    if(Global || !TestTmp.changeable) {
        tmp[0].kind = 0;
        if(TestTmp.ident_kind == 0) {
            tmp[0].value = TestTmp.value;
        }
        else if(TestTmp.ident_kind == 1) {
            auto it = TestTmp.arrayValue.begin();
            it += tmp[1].value;
            tmp[0].value = *it;
        }
        else if(TestTmp.ident_kind == 2) {
            auto it = TestTmp.arrayValue.begin();
            it += tmp[1].value * TestTmp.dimension_two + tmp[2].value;
            tmp[0].value = *it;
        }
    }
    else {
        tmp[0].kind = 1;
        tmp[0].name = TestTmp.name;
        tmp[0].offset = tmp[1].value * TestTmp.dimension_two + tmp[2].value;
        if(TestTmp.ident_kind == 0)
            tmp[0].offset = -1;
        tmp[0].fg_offset = TestTmp.fg_offset;
        tmp[0].reg = TestTmp.reg;
    }
    allStack.push(tmp[0]);
    printLexicalExtra("<LVal>\n");
    return return_value;
}
int FuncRParams(funcTable funcTmp,int name) {
    int params_num = 1;
    int test_value;
    bool Error = true;
    st tmp;
    test_value = Exp();
    tmp = allStack.top();
    allStack.pop();
    if(tmp.kind == 0) {
        printf("push %d\n",tmp.value);
    }
    else if(tmp.kind == 1) {
        if(tmp.offset == -1)
            printf("push %s\n",tmp.name.c_str());
        else
            printf("push %s(%d)\n",tmp.name.c_str(),tmp.offset);
    }
    auto it = funcTmp.params_list.begin();
    if(funcTmp.params_num != 0 && it != funcTmp.params_list.end() && funcTmp.name != "error!" && it->ident_kind != test_value) {
        ErrorHanding_e(outLexicalLine[name]);
        Error = false;
    }
    it++;
    while(outLexicalToken[now_token] == "COMMA") {
        printLexicalOutput(now_token++);    // ,
        test_value = Exp();
        tmp = allStack.top();
        allStack.pop();
        if(tmp.kind == 0) {
            printf("push %d\n",tmp.value);
        }
        else if(tmp.kind == 1) {
            if(tmp.offset == -1)
                printf("push %s\n",tmp.name.c_str());
            else
                printf("push %s(%d)\n",tmp.name.c_str(),tmp.offset);
        }
        params_num++;
        if(funcTmp.params_num != 0 && it != funcTmp.params_list.end() && funcTmp.name != "error!" && it->ident_kind != test_value && Error) {
            Error = false;
            ErrorHanding_e(outLexicalLine[name]);
        }
        it++;
    }
    printLexicalExtra("<FuncRParams>\n");
    return params_num;
}
int PrimaryExp() {
    st tmp;
    int return_value = 0;
    if(outLexicalToken[now_token] == "LPARENT") {
        printLexicalOutput(now_token++);   // (
        return_value = Exp();
        printLexicalOutput(now_token++);   // )
    }
    else if(outLexicalToken[now_token] == "INTCON") {
        tmp.kind = 0;
        tmp.value = StringToNumber(outLexicalWord[now_token]);
        allStack.push(tmp);
        printLexicalOutput(now_token++);
        printLexicalExtra("<Number>\n");
        return_value = 0;
    }
    else if(outLexicalToken[now_token] == "IDENFR") {
        return_value = LVal();
    }
    printLexicalExtra("<PrimaryExp>\n");
    return return_value;
}
int UnaryExp() {
    int opNum = 0;
    int params_number = 0;
    int name;
    int return_value;
    int minuNum = 0;
    while(outLexicalToken[now_token] == "PLUS" || outLexicalToken[now_token] == "MINU" || outLexicalToken[now_token] == "NOT") {
        if(outLexicalToken[now_token] == "MINU") {
            minuNum++;
        }
        printLexicalOutput(now_token++);
        printLexicalExtra("<UnaryOp>\n");
        opNum++;
    }
    if(outLexicalToken[now_token] == "IDENFR" && outLexicalToken[now_token + 1] == "LPARENT") {
        st tmp;
        funcTable TestTmp = CheckDefineInFunc(now_token);
        if(TestTmp.name == "error!")
            ErrorHanding_c(outLexicalLine[now_token]);
        name = now_token;
        printLexicalOutput(now_token++);    //ident
        printLexicalOutput(now_token++);    //(
        if(outLexicalToken[now_token] != "RPARENT" && outLexicalLine[now_token - 1] == outLexicalLine[now_token] && outLexicalToken[now_token] != "SEMICN") {//no params
            params_number = FuncRParams(TestTmp,name);
        }
        if(params_number != TestTmp.params_num && TestTmp.name != "error!") {
            ErrorHanding_d(outLexicalLine[name]);
        }
        if(outLexicalToken[now_token] != "RPARENT")
            ErrorHanding_j(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);  // )
        tmp.name = "ret";
        tmp.kind = 1;
        tmp.offset = -1;
        tmp.reg = "v0";
        allStack.push(tmp);
        return_value = TestTmp.return_kind;
    }
    else if(outLexicalToken[now_token] == "LPARENT" || outLexicalToken[now_token] == "INTCON" || outLexicalToken[now_token] == "IDENFR") {
        return_value = PrimaryExp();
    }
    while(opNum > 0) {
        printLexicalExtra("<UnaryExp>\n");
        opNum--;
    }
    if(minuNum % 2 != 0) {
        if(allStack.top().kind == 0) {
            allStack.top().value = -allStack.top().value;
        }
        else {
            st a = allStack.top();
            allStack.pop();
            allStack.push(negReg(a));
        }
    }
    printLexicalExtra("<UnaryExp>\n");
    return return_value;
}
int MulExp() {
    int return_value;
    string doing;
    return_value = UnaryExp();
    while(outLexicalToken[now_token] == "MULT" || outLexicalToken[now_token] == "DIV" || outLexicalToken[now_token] == "MOD") {
        printLexicalExtra("<MulExp>\n");
        doing = outLexicalToken[now_token];
        printLexicalOutput(now_token++);
        UnaryExp();
        operation(doing);
    }
    printLexicalExtra("<MulExp>\n");
    return return_value;
}
int AddExp() {
    int return_value;
    string doing;
    return_value = MulExp();
    printLexicalExtra("<AddExp>\n");
    while(outLexicalToken[now_token] == "PLUS" || outLexicalToken[now_token] == "MINU") {
        doing = outLexicalToken[now_token];
        printLexicalOutput(now_token++);
        MulExp();
        operation(doing);
        printLexicalExtra("<AddExp>\n");
    }
    return return_value;
}
bool ConstExp() {
    AddExp();
    printLexicalExtra("<ConstExp>\n");
    return true;
}
bool ConstInitVal() {
    if(outLexicalToken[now_token] != "LBRACE") {
        ConstExp();
        st tmp = allStack.top();
        allStack.pop();
        if(Global && ConstIdentTable.back().ident_kind  ==  0)
            ConstIdentTable.back().value = tmp.value;
        else if(Global && ConstIdentTable.back().ident_kind != 0)
            ConstIdentTable.back().arrayValue.emplace_back(tmp.value);
        else if(!Global && allSymbolTable.back().back().ident_kind == 0)
            allSymbolTable.back().back().value = tmp.value;
        else if(!Global && allSymbolTable.back().back().ident_kind == 1)
            allSymbolTable.back().back().arrayValue.emplace_back(tmp.value);
    }
    else {
        printLexicalOutput(now_token++); // {
        if(outLexicalToken[now_token] == "RBRACE") {        //maybe error : in extra rule, this is undefined
            printLexicalOutput(now_token++); // }
            printLexicalExtra("<ConstInitVal>\n");
            return false;
        }
        ConstInitVal();
        while(outLexicalToken[now_token] == "COMMA") {
            printLexicalOutput(now_token++);
            ConstInitVal();
        }
        printLexicalOutput(now_token++); // }
    }
    printLexicalExtra("<ConstInitVal>\n");
    return true;
}
bool ConstDef() {
    int Ident_di = 0;
    int name = now_token;
    st tmp[3];
    printLexicalOutput(now_token++);    //Ident
    while(outLexicalToken[now_token] == "LBRACK") {
        Ident_di++;
        printLexicalOutput(now_token++); // [
        ConstExp();
        tmp[Ident_di] = allStack.top();
        allStack.pop();
        if(outLexicalToken[now_token] != "RBRACK")
            ErrorHanding_k(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++); //]
    }
    if(Global) {
        GlobalConstTable(name,Ident_di);
        if(Ident_di >= 1)
            ConstIdentTable.back().dimension_one = tmp[1].value;
        if(Ident_di == 2)
            ConstIdentTable.back().dimension_two = tmp[2].value;
        printDef(ConstIdentTable.back());
    }
    else {
        SymbolTable(name,Ident_di, false);
        if(Ident_di >= 1)
            allSymbolTable.back().back().dimension_one = tmp[1].value;
        if(Ident_di == 2)
            allSymbolTable.back().back().dimension_two = tmp[2].value;
        printDef(allSymbolTable.back().back());
    }
    printLexicalOutput(now_token++);  // =
    ConstInitVal();
    printLexicalExtra("<ConstDef>\n");
    return true;
}
bool ConstDecl() {
    printLexicalOutput(now_token++);    //const
    printLexicalOutput(now_token++);    // int
    ConstDef();
    while(outLexicalToken[now_token] == "COMMA") {
        printLexicalOutput(now_token++);    //,
        ConstDef();
    }
    if(outLexicalToken[now_token] != "SEMICN")
        ErrorHanding_i(outLexicalLine[now_token - 1]);
    else
        printLexicalOutput(now_token++);    //;
    printLexicalExtra("<ConstDecl>\n");
    return true;
}
bool InitVal() {
    st tmp;
    if(outLexicalToken[now_token] == "LBRACE") {
        printLexicalOutput(now_token++);    // {
        if(outLexicalToken[now_token] == "RBRACE") {
            printLexicalOutput(now_token++);
            printLexicalExtra("<InitVal>\n");
            return true;
        }
        InitVal();
        while(outLexicalToken[now_token] == "COMMA") {
            printLexicalOutput(now_token++);    // ,
            InitVal();
        }
        printLexicalOutput(now_token++);    // }
    }
    else {
        Exp();
        tmp = allStack.top();
        allStack.pop();
        if(Global && UsualIdentTable.back().ident_kind == 0)
            UsualIdentTable.back().value = tmp.value;
        else if(Global && UsualIdentTable.back().ident_kind != 0) {
            UsualIdentTable.back().arrayValue.emplace_back(tmp.value);
        }
        else if(!Global && allSymbolTable.back().back().init) {
            if(tmp.kind == 0) {
                if(allSymbolTable.back().back().ident_kind == 0) {
                    printVarDef(allSymbolTable.back().back(),tmp.value);
                    allSymbolTable.back().back().value = tmp.value;
                }
                else
                    allSymbolTable.back().back().arrayValue.emplace_back(tmp.value);
                printDef(allSymbolTable.back().back());
            }
            if(tmp.kind == 1) {
                printDef(allSymbolTable.back().back());
                st tt;
                tt.name = allSymbolTable.back().back().name;
                tt.reg = allSymbolTable.back().back().reg;
                tt.fg_offset = allSymbolTable.back().back().fg_offset;
                equalOperation(tt,tmp);
                ret(tmp.name);
            }
        }
    }
    printLexicalExtra("<InitVal>\n");
    return true;
}
bool varDef() {
    int Ident_di = 0;
    int name = now_token;
    st tmp[3];
    if(outLexicalToken[now_token] == "IDENFR") {    // else, the varDef should exit
        printLexicalOutput(now_token++);    // a
        while(outLexicalToken[now_token] == "LBRACK") {
            Ident_di++;
            printLexicalOutput(now_token++);    // [
            ConstExp();
            tmp[Ident_di] = allStack.top();
            allStack.pop();
            if(outLexicalToken[now_token] != "RBRACK")
                ErrorHanding_k(outLexicalLine[now_token - 1]);
            else
                printLexicalOutput(now_token++); //]
        }
        if(Global) {
            GlobalVarTable(name,Ident_di);
            if(Ident_di >= 1)
                UsualIdentTable.back().dimension_one = tmp[1].value;
            if(Ident_di == 2)
                UsualIdentTable.back().dimension_two = tmp[2].value;
        }
        else {
            SymbolTable(name,Ident_di, true);
            if(Ident_di >= 1)
                allSymbolTable.back().back().dimension_one = tmp[1].value;
            if(Ident_di == 2)
                allSymbolTable.back().back().dimension_two = tmp[2].value;
            getReg();
        }
        if(outLexicalToken[now_token] == "ASSIGN") {
            printLexicalOutput(now_token++);    // =
            if(Global)
                UsualIdentTable.back().init = true;
            else
                allSymbolTable.back().back().init = true;
            InitVal();
        }
        if(!UsualIdentTable.empty() && Global && !UsualIdentTable.back().init) {
            if(Ident_di == 0) {
                UsualIdentTable.back().value = 0;
            }
            else if(Ident_di == 1) {
                int i = 0;
                for(;i < UsualIdentTable.back().dimension_one;i++)
                    UsualIdentTable.back().arrayValue.emplace_back(0);
            }
            else if(Ident_di == 2) {
                int i = 0;
                for(;i < UsualIdentTable.back().dimension_one * UsualIdentTable.back().dimension_two;i++)
                    UsualIdentTable.back().arrayValue.emplace_back(0);
            }
        }
        if(Global)
            newGlobalVar(UsualIdentTable.back());
        if(!allSymbolTable.empty() && !Global && !allSymbolTable.back().back().init)
            printDef(allSymbolTable.back().back());
    }
    printLexicalExtra("<VarDef>\n");
    return true;
}
bool VarDecl() {
    printLexicalOutput(now_token++);    // int
    varDef();
    while(outLexicalToken[now_token] == "COMMA") {
        printLexicalOutput(now_token++);    // ,
        varDef();
    }
    if(outLexicalToken[now_token] != "SEMICN")
        ErrorHanding_i(outLexicalLine[now_token - 1]);
    else
        printLexicalOutput(now_token++);
    printLexicalExtra("<VarDecl>\n");
    return true;
}
bool Decl() {
    if(outLexicalToken[now_token] == "CONSTTK") {
        ConstDecl();
        return true;
    }
    else if(outLexicalToken[now_token + 2] != "LPARENT") {
        VarDecl();
        return true;
    }
    return false;
}
bool RelExp() {
    AddExp();
    printLexicalExtra("<RelExp>\n");
    while(outLexicalToken[now_token] == "LSS" || outLexicalToken[now_token] == "LEQ" || outLexicalToken[now_token] == "GRE" || outLexicalToken[now_token] == "GEQ") {
        printLexicalOutput(now_token++);    // > < >= <=
        AddExp();
        printLexicalExtra("<RelExp>\n");
    }
    return true;
}
bool EqExp() {
    RelExp();
    printLexicalExtra("<EqExp>\n");
    while(outLexicalToken[now_token] == "EQL" || outLexicalToken[now_token] == "NEQ") {
        printLexicalOutput(now_token++);    // != ==
        RelExp();
        printLexicalExtra("<EqExp>\n");
    }
    return true;
}
bool LandExp() {
    EqExp();
    printLexicalExtra("<LAndExp>\n");
    while(outLexicalToken[now_token] == "AND") {
        printLexicalOutput(now_token++);    // &&
        EqExp();
        printLexicalExtra("<LAndExp>\n");
    }
    return true;
}
bool LOrExp() {
    LandExp();
    printLexicalExtra("<LOrExp>\n");
    while(outLexicalToken[now_token] == "OR") {
        printLexicalOutput(now_token++);    // ||
        LandExp();
        printLexicalExtra("<LOrExp>\n");
    }
    return true;
}
bool FormatString() {
    ErrorHanding_a_string(outLexicalWord[now_token],outLexicalLine[now_token]);
    printLexicalOutput(now_token++);    //string
    return true;
}
bool Cond() {
    LOrExp();
    printLexicalExtra("<Cond>\n");
    return true;
}
bool Stmt() {
    st quaternion[3];
    if(outLexicalToken[now_token] == "LBRACE") {
        Block();
    }
    else if(outLexicalToken[now_token] == "IFTK") {
        printLexicalOutput(now_token++); // if
        printLexicalOutput(now_token++);    // (
        Cond();
        if(outLexicalToken[now_token] != "RPARENT")
            ErrorHanding_j(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);    // )
        Stmt();
        if(outLexicalToken[now_token] == "ELSETK") {
            printLexicalOutput(now_token++);    // else
            Stmt();
        }
    }
    else if(outLexicalToken[now_token] == "WHILETK") {
        cycleDepth++;
        printLexicalOutput(now_token++); //while
        printLexicalOutput(now_token++); // (
        Cond();
        if(outLexicalToken[now_token] != "RPARENT")
            ErrorHanding_j(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);    // )
        Stmt();
        cycleDepth--;
    }
    else if(outLexicalToken[now_token] == "BREAKTK" || outLexicalToken[now_token] == "CONTINUETK") {
        printLexicalOutput(now_token++);    // break or continue
        if(outLexicalToken[now_token] != "SEMICN")
            ErrorHanding_i(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);    // ;
        if(cycleDepth == 0)
            ErrorHanding_m(outLexicalLine[now_token - 1]);
    }
    else if(outLexicalToken[now_token] == "RETURNTK") {
        int name = now_token;
        printLexicalOutput(now_token++);    // return
        if(outLexicalToken[now_token] == "RBRACE") {
            ErrorHanding_i(outLexicalLine[now_token - 1]);
            near_return_final = now_token - 1;
        }
        else {
            bool HasExp = false;
            if(outLexicalToken[now_token] != "SEMICN" && outLexicalLine[now_token - 1] == outLexicalLine[now_token]) {
                Exp();
                st tmp = allStack.top();
                allStack.pop();

                if(tmp.kind == 0) {
                    printf("ret %d\n",tmp.value);
                }
                else {
                    if(tmp.offset != -1)
                        printf("ret %s(%d)\n",tmp.name.c_str(),tmp.offset);
                    else
                        printf("ret %s\n",tmp.name.c_str());
                }
                HasExp = true;
            }
            near_return_final = now_token;
            if(FuncTable.back().return_kind == 1 && HasExp)
                ErrorHanding_f(outLexicalLine[name]);
            if(outLexicalToken[now_token] != "SEMICN")
                ErrorHanding_i(outLexicalLine[now_token - 1]);
            else
                printLexicalOutput(now_token++);    // ;
        }
    }
    else if(outLexicalToken[now_token] == "PRINTFTK") {
        printLexicalOutput(now_token++); // printf
        printLexicalOutput(now_token++); // (
        FormatString();
        int NowHave = 0;
        st tmp;
        string split;
        string FormatStr = outLexicalWord[now_token - 1];
        auto it = FormatStr.begin() + 1;
        while(*it != '%' && it + 1 != FormatStr.end()) {
            split.push_back(*it);
            it++;
        }
        if(!split.empty()) {
            data_string.emplace_back(split);
            printf("print str_%zu\n",data_string.size());
            printStr((int )data_string.size());
            split.clear();
        }
        if(*it == '%') {
            it++;  it++; // %d
        }
        while(outLexicalToken[now_token] == "COMMA") {
            printLexicalOutput(now_token++); // ,
            Exp();
            tmp = allStack.top();
            allStack.pop();
            if(tmp.kind == 0) {
                printf("print %d\n",tmp.value);
                printNum(tmp.value);
            }
            else {
                printf("print %d %s\n",tmp.offset,tmp.name.c_str());
                if(tmp.offset == -1) {
                    printVar(tmp);
                }
            }
            while(*it != '%' && it + 1 != FormatStr.end()) {
                split.push_back(*it);
                it++;
            }
            if(!split.empty()) {
                data_string.emplace_back(split);
                printf("print str_%zu\n",data_string.size());
                printStr((int )data_string.size());
                split.clear();
            }
            if(*it == '%') {
                it++;  it++; // %d
            }
            NowHave++;
        }
        ErrorHanding_l(outLexicalLine[now_token - 1],FormatStr,NowHave);
        if(outLexicalToken[now_token] != "RPARENT")
            ErrorHanding_j(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);    // )
        if(outLexicalToken[now_token] != "SEMICN")
            ErrorHanding_i(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);    // ;
    }
    else {
        bool isExp = true;
        int i = now_token;
        while (i < outLexicalToken.size() - 1 && outLexicalToken[i] != "SEMICN" && outLexicalLine[i] == outLexicalLine[i + 1]) {
            if(outLexicalToken[i] == "ASSIGN") {
                isExp = false;
                break;
            }
            i++;
        }
        if(isExp) {
            if(outLexicalToken[now_token] != "SEMICN")
                Exp();
            if(outLexicalToken[now_token] != "SEMICN")
                ErrorHanding_i(outLexicalLine[now_token - 1]);
            else
                printLexicalOutput(now_token++); // ;
        }
        else {
            identTable tmp = CheckDefineInIdent(now_token);
            if(!tmp.changeable)
                ErrorHanding_h(outLexicalLine[now_token]);
            LVal();
            printLexicalOutput(now_token++);    // =
            if(outLexicalToken[now_token] == "GETINTTK") {
                printLexicalOutput(now_token++); // getint
                printLexicalOutput(now_token++); // (
                if(outLexicalToken[now_token] != "RPARENT")
                    ErrorHanding_j(outLexicalLine[now_token - 1]);
                else
                    printLexicalOutput(now_token++);    // )
                quaternion[1] = allStack.top();
                allStack.pop();
                getInt(quaternion[1]);
                printf("scanf t6\n");
                printf("%s = t6\n",quaternion[1].name.c_str());
                ret(quaternion[1].name);
            }
            else {
                Exp();
                quaternion[2] = allStack.top();
                allStack.pop();
                quaternion[1] = allStack.top();
                allStack.pop();
                equalOperation(quaternion[1],quaternion[2]);
                ret(quaternion[2].name);
            }
            if(outLexicalToken[now_token] != "SEMICN")
                ErrorHanding_i(outLexicalLine[now_token - 1]);
            else
                printLexicalOutput(now_token++); // ;
        }
    }
    printLexicalExtra("<Stmt>\n");
    return true;
}
bool BlockItem() {
    if(outLexicalToken[now_token] == "CONSTTK" || outLexicalToken[now_token] == "INTTK")
        Decl();
    else
        Stmt();
    return true;
}
bool Block() {
    (allSymbolTable.back()).emplace_back();
    (allSymbolTable.back()).back().name = "{";
//    printf("%s \n",(allSymbolTable.back()).back().name.c_str());
    printLexicalOutput(now_token++); // {
    while(outLexicalToken[now_token] != "RBRACE")
        BlockItem();
    (allSymbolTable.back()).emplace_back();
    (allSymbolTable.back()).back().name = "}";
    printLexicalOutput(now_token++);    // }
    printLexicalExtra("<Block>\n");
    return true;
}
#pragma clang diagnostic pop
bool FuncFParam() {
    st tmp;
    int Number_di = 0;
    int name;
    printLexicalOutput(now_token++); // int
    name = now_token;
    printLexicalOutput(now_token++); // Ident
    if(outLexicalToken[now_token] == "LBRACK") {    // has one
        Number_di = 1;
        printLexicalOutput(now_token++);    // [
        if(outLexicalToken[now_token] != "RBRACK")
            ErrorHanding_k(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++); //]
    }
    if(outLexicalToken[now_token] == "LBRACK")  {    // has two []
        Number_di = 2;
        printLexicalOutput(now_token++);    // [
        ConstExp();
        if(outLexicalToken[now_token] != "RBRACK")
            ErrorHanding_k(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++); //]
    }
    GlobalFuncParamsTable(name,Number_di);
    if(Number_di == 2) {
        tmp = allStack.top();
        allStack.pop();
        FuncTable.back().params_list.back().dimension_two = tmp.value;
    }
    FuncTable.back().params_list.back().fg_offset = gpReg;
    gpReg += 4;
    printLexicalExtra("<FuncFParam>\n");
    return true;
}
bool FuncFParams() {
    int params_num = 1;
    FuncFParam();
    while(outLexicalToken[now_token] == "COMMA") {
        printLexicalOutput(now_token++);    // ,
        FuncFParam();
        params_num++;
    }
    printLexicalExtra("<FuncFParams>\n");
    return true;
}
bool Func() {
    if(outLexicalToken[now_token + 1] == "MAINTK") {
        return false;
    }
    int return_kind;
    int name;
    vector<identTable> symbolTable;
    allSymbolTable.emplace_back(symbolTable);
    if(outLexicalToken[now_token] == "VOIDTK" || outLexicalToken[now_token] == "INTTK") {
        if(outLexicalToken[now_token] == "VOIDTK")
            return_kind = 1;
        else
            return_kind = 0;
        printLexicalOutput(now_token++);    // int or void
        printLexicalExtra("<FuncType>\n");
        name = now_token;
        newFunc(outLexicalWord[name]);
        printLexicalOutput(now_token++);    // ident
        printLexicalOutput(now_token++);    // (
        GlobalFuncTable(name,return_kind);
        if(outLexicalToken[now_token] != "RPARENT" && outLexicalToken[now_token] != "LBRACE") {
            FuncFParams();      // in there, we sure the func has params
        }
        if(outLexicalToken[now_token] != "RPARENT")
            ErrorHanding_j(outLexicalLine[now_token - 1]);
        else
            printLexicalOutput(now_token++);    // )
        if(QuaternionOutPut) {
            printf("%s %s()\n",FuncTable.back().return_kind == 1?"void":"int",FuncTable.back().name.c_str());
            auto it = FuncTable.back().params_list.begin();
            for(;it != FuncTable.back().params_list.end();it++) {
                if(it->ident_kind == 0)
                    printf("para %s\n",it->name.c_str());
                else if(it->ident_kind == 1)
                    printf("para[] %s\n",it->name.c_str());
                else if(it->ident_kind == 2)
                    printf("para[][%d] %s\n",it->dimension_two,it->name.c_str());
            }
        }
        Block();    // this is the beginning of table // 10 20 22 51
        if(now_token - 2 != near_return_final && FuncTable.back().return_kind == 0)
            ErrorHanding_g(outLexicalLine[now_token - 1]);
    }
    printLexicalExtra("<FuncDef>\n");
    funcReturn();
    return true;
}
bool MainFunc() {
    printLexicalOutput(now_token++);  // int
    GlobalFuncTable(now_token,0);
    newFunc(outLexicalWord[now_token]);
    printLexicalOutput(now_token++);    // main
    printLexicalOutput(now_token++);    // (
    printLexicalOutput(now_token++); // )
    if(QuaternionOutPut) {
        printf("%s %s()\n",FuncTable.back().return_kind == 1?"void":"int",FuncTable.back().name.c_str());
    }
    vector<identTable> symbolTable;
    allSymbolTable.emplace_back(symbolTable);
    Block();
    if(now_token - 2 != near_return_final)
        ErrorHanding_g(outLexicalLine[now_token - 1]);
    printLexicalExtra("<MainFuncDef>\n");
    return true;
}
void Syntactic() {
    while(now_token < outLexicalToken.size() && Decl());
    Global = false;
    while(now_token < outLexicalToken.size() && Func());
    if(now_token < outLexicalToken.size())
        MainFunc();
    printLexicalExtra("<CompUnit>\n");
}
#endif //COMPILER_SYNTACTIC_H