#include <iostream>
#include "Lexical.h"
#include "Syntactic.h"
#include "Mips.h"
#include "debug.h"
using namespace std;
int main() {
    initReg();
    freopen("testfile.txt","r",stdin);
    freopen("error.txt","w",stdout);
    Lexical();
    Syntactic();
    mipsInit();
    return 0;
}
